
const express = require("express");
const mongoose = require("mongoose");


const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI ="mongodb+srv://abhisheksingh2474352:h0ygWvrZvVPs2gNv@cluster0.yy8bq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error);
  });


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});